#ifndef CTELNET_H_
#define CTELNET_H_

#endif // CTELNET_H_


void parseTelnet();


