#include "Display.h"
	
Display :: Display(){
	return;
}	
	
void Display :: update(){
	return;
}

void Display :: showMode(std::string pMode) { 
	return;
}

void Display :: showSpeed(float pSpeed){
	return;
}

void Display :: showID(int prightConvID, int pleftConvID){
	return;
}
