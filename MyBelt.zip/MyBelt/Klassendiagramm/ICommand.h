#ifndef ICommand_H_
#define ICommand_H_

class ICommand{
public:
	ICommand();
	void parseCommand();
};

#endif // ICommand_H_

