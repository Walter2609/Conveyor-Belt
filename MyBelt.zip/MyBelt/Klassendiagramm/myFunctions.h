
#ifndef MYFUNCTIONS_H_
#define MYFUNCTIONS_H_

void myAction00();
void myAction01();
void myAction02();
void myAction03();
void myAction04();
void myAction05();
void myAction06();
void myAction07();
void myAction08();

void myAction10();
void myAction11();
void myAction12();
void myAction13();
void myAction14();
void myAction15();
void myAction16();
void myAction17();
void myAction18();

void myAction20();

void myAction30();

bool myConditionTrue();

bool myCondition00();
bool myCondition01();

bool myCondition11();
bool myCondition12();

#endif // MYFUNCTIONS_H_
