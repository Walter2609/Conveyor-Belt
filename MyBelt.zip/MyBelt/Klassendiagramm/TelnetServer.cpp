#include "TelnetServer.h"
#include <vxWorks.h>
#include <sockLib.h>
#include <stdlib.h>
#include <stdioLib.h>
#include <strLib.h>
#include <stdio.h>
#include <ioLib.h>
#include <fioLib.h>
#include <intLib.h>
#include <inetLib.h>
#include <taskLib.h>
#include <sysLib.h>
#include <time.h>
#include <string.h>
#include "hwFunc.h"
#include "disp.h"
#include "FHV.h"
#include "hw.h"
#include "MyBelt.h"
#include "stateMachine.h"


#define SERVER_PORT_NUM 4444 /* server's port number for bind() */
#define SERVER_WORK_PRIORITY 100 /* priority of server's work task */
#define SERVER_STACK_SIZE 10000 /* stack size of server's work task */
#define SERVER_MAX_CONNECTIONS 4 /* max clients connected at a time */
#define REQUEST_MSG_SIZE 1024 /* max size of request message */
#define REPLY_MSG_SIZE 500 /* max size of reply message */
/* structure for requests from clients to server */

StateMachine * myStateMachine;
VOID telnetServerWorkTask (int sFd, char * address, u_short port);

struct request
{
	int reply; /* TRUE = request reply from server */
	int msgLen; /* length of message text */
	char message[REQUEST_MSG_SIZE]; /* message buffer */
};



TelnetServer :: TelnetServer(){
	printf("Telnet Konstruktor!\n\r");	
		return;
	}	


void TelnetServer :: receiveCommand(){
		return;
	}
	

void TelnetServer :: sendCommand(){
		return;
	}


STATUS rTelnetS(void)
{
	struct sockaddr_in serverAddr; // server's socket address 
	struct sockaddr_in clientAddr; // client's socket address 
	int sockAddrSize; // size of socket address structure 
	int sFd; // socket file descriptor 
	int newFd; // socket descriptor from accept 
	int ix = 0; // counter for work task names 
	char workName[16]; // name of work task 
	
	// set up the local address
	
	socklen_t len = sizeof(clientAddr);
	sockAddrSize = sizeof (struct sockaddr_in);
	bzero ((char *) &serverAddr, sockAddrSize);
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_len = (u_char) sockAddrSize;
	serverAddr.sin_port = htons (SERVER_PORT_NUM);
	serverAddr.sin_addr.s_addr = htonl (INADDR_ANY);
	
	// create a Telnet-based socket 
	
	if ((sFd = socket (AF_INET, SOCK_STREAM, 0)) == ERROR)
	{
		perror ("socket");
		return (ERROR);
	}
	
	// bind socket to local address 
	if (bind (sFd, (struct sockaddr *) &serverAddr, sockAddrSize) == ERROR)
	{
		perror ("bind");
		close (sFd);
		return (ERROR);
	}
	
	// create queue for client connection requests 
	if (listen (sFd, SERVER_MAX_CONNECTIONS) == ERROR)
	{
		perror ("listen");
		close (sFd);
		return (ERROR);
	}
	
	// accept new connect requests and spawn tasks to process them 
	FOREVER
	{
		int len = sizeof(clientAddr);
		if ((newFd = accept (sFd, (struct sockaddr *) &clientAddr, &len)) == ERROR)
		{
			perror ("accept");
			close (sFd);
			return (ERROR);
		}
		
		sprintf (workName, "tTelnetWork%d", ix++);
		if (taskSpawn(workName, SERVER_WORK_PRIORITY, 0, SERVER_STACK_SIZE, (FUNCPTR) telnetServerWorkTask, newFd,
			(int) inet_ntoa (clientAddr.sin_addr), ntohs (clientAddr.sin_port), 0, 0, 0, 0, 0, 0, 0) == ERROR)
		{
			// if taskSpawn fails, close fd and return to top of loop 
			perror ("taskSpawn");
			close (newFd);
		}
	}
}

// structure for requests from clients to server 
VOID telnetServerWorkTask( int sFd, //server's socket fd
						char * address, // client's socket address 
						u_short port /* client's socket port*/ ) 
{
	//char outputstring1[77];
	//request/message from client
	struct request clientRequest;  
	int nRead; /* number of bytes read */
	static char replyMsg[] = "Server received your message";
	static char welcomeMsg[] = "Hallo....ich bin Emines und Walters TelnetServerWorkTask\n";
	/* read client request, display message */

		write(sFd,welcomeMsg,sizeof(welcomeMsg));
		//OLD:while ((nRead = fioRead (sFd, (char *) &clientRequest,
		//                         sizeof (clientRequest))) > 0)
		//new
		while ((nRead = fioRdString (sFd, (char *) &clientRequest.message,
			                         sizeof (clientRequest.message))) > 0)
		//endnew
		{
	
		switch (clientRequest.message[0])
		{
			//LOM
		case '0':
			static char outputstring1[]= "0_stop\n";	
			myStateMachine->sendEvent("0_stop");
			write(sFd, outputstring1, sizeof(outputstring1));
			break;		
		case '1':
			static char outputstring2[]= "1_keyDriveLeft\n";
			myStateMachine->sendEvent("1_keyDriveLeft");
			write(sFd, outputstring2, sizeof(outputstring2));
			break;			
		case '3':
			static char outputstring3[]= "3_keyDriveRight\n";
			myStateMachine->sendEvent("3_keyDriveRight");
			write(sFd, outputstring3, sizeof(outputstring3));
			break;								
		case '4':
			static char outputstring4[]= "4_speedDown\n";
			myStateMachine->sendEvent("4_speedDown");
			write(sFd, outputstring4, sizeof(outputstring4));
			break;			
		case '6':
			static char outputstring5[]= "6_speedUp\n";
			myStateMachine->sendEvent("6_speedUp");
			write(sFd, outputstring5, sizeof(outputstring5));
			break;			
		case 'F':
			static char outputstring6[]= "F_finishedProfile\n";
			myStateMachine->sendEvent("F_finishedProfile");
			write(sFd, outputstring6, sizeof(outputstring6));
			break;				
		case 'E':
			static char outputstring7[]= "E_changeMode_COM_to_LOM\n";
			myStateMachine->sendEvent("E_changeMode_COM_to_LOM");
			write(sFd, outputstring7, sizeof(outputstring7));
			break;	
			
//******************************************************************************			
		
			//COM
		case 'A':
			static char outputstring8[]= "A_requestReceived\n";
			myStateMachine->sendEvent("A_requestReceived");
			write(sFd, outputstring8, sizeof(outputstring8));
			break;			
		case '7':
			static char outputstring9[]= "7_releaseSentToLeft\n";
			myStateMachine->sendEvent("7_releaseSentToLeft");
			write(sFd, outputstring9, sizeof(outputstring9));
			break;	
		case '8':
			static char outputstring10[]= "8_waitReceived\n";
			myStateMachine->sendEvent("8_waitReceived");
			write(sFd, outputstring10, sizeof(outputstring10));
			break;
		case '9':
			static char outputstring11[]= "9_sendToLeftWait\n";
			myStateMachine->sendEvent("9_sendToLeftWait");
			write(sFd, outputstring11, sizeof(outputstring11));
			break;			
		case 'B':
			static char outputstring12[]= "B_readyReceived\n";
			myStateMachine->sendEvent("B_readyReceived");
			write(sFd, outputstring12, sizeof(outputstring12));
			break;		
		case 'C':
			static char outputstring13[]= "C_releasedReceivedFromRight\n";
			myStateMachine->sendEvent("C_releasedReceivedFromRight");
			write(sFd, outputstring13, sizeof(outputstring13));
			break;		
		case 'D':
			static char outputstring14[]= "D_changeMode_LOM_to_COM\n";
			myStateMachine->sendEvent("D_changeMode_LOM_to_COM");
			write(sFd, outputstring14, sizeof(outputstring14));
			break;					
		
		default:
			
			break;
		}
		//write(sFd, outputstring1, sizeof(outputstring1));
	}	
	if (nRead == ERROR) /* error from read() */
		perror ("read");
	close (sFd); /* close server socket connection */
	//...
	//...
	//...
}





void TelnetServer :: init() {
	taskSpawn("myTelnetServer", 101, 0, 0x1000,  (FUNCPTR) rTelnetS, 0,0,0,0,0,0,0,0,0,0);
	return;
}


