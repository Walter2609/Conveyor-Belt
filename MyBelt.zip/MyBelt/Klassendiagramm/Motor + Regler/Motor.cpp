#include "Motor.h"
	
Motor :: Motor() {
	return;
}

void Motor :: run() {
	return;
}

 void Motor :: stop() {
	return;
}

 void Motor :: setSpeed(float Speed){
	return;
}

 void Motor :: getSpeed(){
	return;
}

 void Motor :: riseTimeMovement(){
	return;
}

 void Motor :: fallTimeMovement(){
	return;
}

 void Motor :: setDirection(std::string pDirection){
	return;
}

