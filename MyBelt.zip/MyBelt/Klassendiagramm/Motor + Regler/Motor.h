
#ifndef MOTOR_H_
#define MOTOR_H_

#include <string>

class Motor{
	
private:
	float mSpeed;
	std::string mDirection;

public:
	Motor();
	void run();
	void stop();
	void setSpeed(float Speed);
	void getSpeed();
	void riseTimeMovement();
	void fallTimeMovement();
	void setDirection(std::string pDirection);
};

#endif // MOTOR_H_
