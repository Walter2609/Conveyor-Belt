#ifndef REGLER_H_
#define REGLER_H_

class Regler {
	
	private:
	float actualSpeed;
	float desiredSpeed;
	
	public:
		Regler();
		void setAmplitude();
		void getAmplitude();
};

#endif // REGLER_H_

