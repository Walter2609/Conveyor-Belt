#include "Regler.h"


Regler :: Regler(){
	return;
}
	
void Regler :: setAmplitude(){
	return;
}

void Regler :: getAmplitude(){
	return;
}
