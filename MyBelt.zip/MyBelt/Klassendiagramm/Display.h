#ifndef DISPLAY_H_
#define DISPLAY_H_

#include <string>

class Display{
	
private:
	std::string mMode;
	float mSpeed;
	int mrightConvID;
	int mleftConvID;
	
public:
	Display();
	void update();
	void showMode(std::string pMode); 
	void showSpeed(float pSpeed);
	void showID(int prightConvID, int pleftConvID);
};

#endif // DISPLAY_H_
