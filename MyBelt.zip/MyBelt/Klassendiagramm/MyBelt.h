
#ifndef MyBelt_H_
#define MyBelt_H_


//#include "Regler.h"
#include "TCPServer.h"
#include "TelnetServer.h"
#include "TCPClient.h"
//#include "Display.h"
//#include "ICommand.h"
#include "taskLibCommon.h"

class MyBelt{
	//private:
	//Motor mMotor;
	//int mleftConvID;
	//Regler mRegler;
	//Display mDisplay;
	//std::string mMode;
	//int mrightConvID;
	//int mProfile[];
	//std::string mDirection;
	//boolean requestReceived;
	//boolean releaseReceived;
	//boolean waitReceived;
	//boolean sendtoLeftWait;
	//boolean releaseReceivedFromRight;
	//boolean relaseSendToLeft;


public:
	//MyBelt(Regler mRegler, Display mDisplay, Motor mMotor);
	MyBelt ();
	// Funktionen hier nennen die vom Pilsan hinzugekommen sind.....
	//.....
	void speedDown(int a);
	void speedUp(int b);
	void keyDriveLeft();
	void keyDriveRight();
	void finishedProfile();
	void stop();
	
};

#endif // MyBelt_H_
