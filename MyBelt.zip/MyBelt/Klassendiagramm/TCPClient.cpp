
//#include <stdio.h>
//#include <sockLib.h>
//#include <inetLib.h>
//#include "FHV.h"
#include "TCPClient.h"
#include <vxWorks.h>
#include <sockLib.h>
#include <stdlib.h>
#include <stdioLib.h>
#include <strLib.h>
#include <stdio.h>
#include <ioLib.h>
#include <fioLib.h>
#include <intLib.h>
#include <inetLib.h>
#include <taskLib.h>
#include <sysLib.h>
#include <time.h>
#include <string.h>
#include "hostLib.h"
#include "hwFunc.h"
#include "disp.h"
#include "FHV.h"
#include "hw.h"
#include "MyBelt.h"
#include "stateMachine.h"

// Dies muss sp�ter noch "dynamisch" auf den Nachbarn auf laut Masterbefehl reagiert werden 
// �Right 91.0.0.k\r\n�, where k is the address of the right neighbor
char * serverName = "91.0.0.105";

#define SERVER_PORT_NUM 5555 /* server's port number for bind() */
#define SERVER_WORK_PRIORITY 100 /* priority of server's work task */
#define SERVER_STACK_SIZE 10000 /* stack size of server's work task */
#define SERVER_MAX_CONNECTIONS 4 /* max clients connected at a time */
#define REQUEST_MSG_SIZE 1024 /* max size of request message */
#define REPLY_MSG_SIZE 500 /* max size of reply message */
/* structure for requests from clients to server */

TCPClient :: TCPClient (){
	printf("TCPClient Konstruktor!\n\r");	
	return;
}

struct request
{	int reply; /* TRUE = request reply from server */
	int msgLen; /* length of message text */
	char message[REQUEST_MSG_SIZE]; /* message buffer */
};



STATUS rTCPC(char * serverName /* name or IP address of server */){
	struct request myRequest; /* request to send to server */
	struct sockaddr_in serverAddr; /* server's socket address */
	char replyBuf[REPLY_MSG_SIZE]; /* buffer for reply */
	int nRead; /* number of bytes read */
	char reply; /* if TRUE, expect reply back */
	int sockAddrSize; /* size of socket address structure */

	int sFd; /* socket file descriptor */
	int mlen; /* length of message */
	/* create client's socket */
	if ((sFd = socket (AF_INET, SOCK_STREAM, 0)) == ERROR)
	{	perror ("socket");
		return (ERROR);
	}
	/* bind not required - port number is dynamic */
	/* build server socket address */
	sockAddrSize = sizeof (struct sockaddr_in);
	bzero ((char *) &serverAddr, sockAddrSize);
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_len = (u_char) sockAddrSize;
	serverAddr.sin_port = htons (SERVER_PORT_NUM);
	
	if (((serverAddr.sin_addr.s_addr = inet_addr (serverName)) == ERROR) &&
		((serverAddr.sin_addr.s_addr = hostGetByName (serverName)) == ERROR))
	{ 	perror ("unknown server name");
		close (sFd);
		return (ERROR);
	}
	
	/* connect to server */
	if (connect (sFd, (struct sockaddr *) &serverAddr, sockAddrSize) == ERROR)
	{	perror ("connect");
		close (sFd);
		return (ERROR);
	}
	
	while ((nRead = fioRdString (sFd, (char *) &myRequest.message,
		                         sizeof (myRequest.message))) > 0)
	{
		//...... fehlt noch: write an Server
		//....... fehlt noch: die Case-�bersetzung --> ServerAntwort->sendEvent("....Trigger")

	    writeToDisplay(1, 1, "Hallo1");
	}
		
	if (nRead == ERROR) /* error from read() */
		perror ("read");
	close (sFd); /* close server socket connection */
}

void TCPClient :: init() {
	taskSpawn("myTCPClient", 101, 0, 0x1000,  (FUNCPTR) rTCPC, 0,0,0,0,0,0,0,0,0,0);
	return;
}



