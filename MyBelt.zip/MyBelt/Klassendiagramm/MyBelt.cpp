#include "MyBelt.h"
#include "stateMachine.h"
#include "keyboard.h"
#include "myFunctions.h"

extern "C" {
	#include "hwFunc.h"
}

void MyBelt :: speedDown(int a){
	return;
}


void speedUp(int b){
	return;
}

void keyDriveLeft(){
	return;	
}

void keyDriveRight(){
	return;	
}

void finishedProfile(){
	return;	
}

void stop(){
	return;	
}

int n, m;
StateMachine * myStateMachine;
Keyboard * myKeyboard;
TCPServer *myTCPServer;
TelnetServer *myTelnetServer;
TCPClient *myTCPClient;
//MyBelt :: MyBelt(Regler mRegler, Display mDisplay, Motor mMotor) {
MyBelt :: MyBelt() {
	// Initialize table for all diagrams, event time in ms (POSIX)
	// The maximum size of the table is defined in stateTable.h:
	// MAXDIA = 9, MAXLINES = 66
	// Should these be exceeded, please correct!

	// Local Operation Mode (LOM)
	tab[0][0] = new TableEntry ("IDLE_LOM",				"IDLE_COM",		"D_changeMode_LOM_to_COM",	0,myAction00,myConditionTrue);
	tab[0][1] = new TableEntry ("IDLE_LOM",				"RunLeft",		"1_keyDriveLeft",				0,myAction01,myConditionTrue);
	tab[0][2] = new TableEntry ("IDLE_LOM",				"RunRight",		"3_keyDriveRight",			0,myAction02,myConditionTrue);
	tab[0][3] = new TableEntry ("RunLeft",				"IDLE_LOM",		"F_finishedProfile",			0,myAction03,myConditionTrue);
	tab[0][4] = new TableEntry ("RunLeft",				"IDLE_LOM",		"0_stop",						0,myAction04,myConditionTrue);
	tab[0][5] = new TableEntry ("RunRight",				"IDLE_LOM",		"F_finishedProfile",			0,myAction05,myConditionTrue);
	tab[0][6] = new TableEntry ("RunRight",				"IDLE_LOM",		"0_stop",						0,myAction06,myConditionTrue);
	tab[0][7] = new TableEntry ("IDLE_LOM",				"IDLE_LOM",		"6_speedUp",					0,myAction07,myConditionTrue);
	tab[0][8] = new TableEntry ("IDLE_LOM",				"IDLE_LOM",		"4_speedDown",				0,myAction08,myConditionTrue);

	// Chain Operarion Mode (COM)
	tab[1][0] = new TableEntry ("IDLE_COM",					"IDLE_LOM",					"E_changeMode_COM_to_LOM",		0,myAction10,myConditionTrue);
	tab[1][1] = new TableEntry ("IDLE_COM",					"PayloadPassingFromLeft",	"A_requestReceived",				0,myAction11,myConditionTrue);
	tab[1][2] = new TableEntry ("PayloadPassingFromLeft",	"MoveProfile",				"7_releaseSentToLeft",			0,myAction12,myConditionTrue);
	tab[1][3] = new TableEntry ("MoveProfile",				"MoveProfile",				"A_requestReceived",				0,myAction13,myConditionTrue);
	tab[1][4] = new TableEntry ("MoveProfile",				"MoveProfile",				"9_sendToLeftWait",				0,myAction14,myConditionTrue);
	tab[1][5] = new TableEntry ("MoveProfile",				"PayloadPassingToRight",	"B_readyReceived",				0,myAction15,myConditionTrue);
	tab[1][6] = new TableEntry ("MoveProfile",				"Stop",						"8_waitReceived",					0,myAction16,myConditionTrue);
	tab[1][7] = new TableEntry ("Stop",						"PayloadPassingToRight",	"B_readyReceived",				0,myAction17,myConditionTrue);
	tab[1][8] = new TableEntry ("PayloadPassingToRight",	"IDLE_COM",					"C_releasedReceivedFromRight",	0,myAction18,myConditionTrue);

	// St�ndige Abfrage (200ms) ob eine Taste gedr�ckt ist
	tab[2][0] = new TableEntry ("KeyPressed","KeyPressed","Timer2",100,myAction20,myConditionTrue);

	// Initialize timer names for all diagrams
	// Timer names are always Timer followed by the diagram number
	timerNames[0] = "Timer0";
	timerNames[1] = "Timer1";
	timerNames[2] = "Timer2";

	// Initialize line numbers for all diagrams
	lines[0] = 9;
	lines[1] = 9;
	lines[2] = 1;

	// Initialize first state for all diagrams
	actualState[0] = "IDLE_LOM";
	actualState[1] = "IDLE_COM";
	actualState[2] = "KeyPressed";
	
	// Set the actual number of diagrams
	diagrams = 3;
	
	// Create instance of my Keyboard
	myKeyboard = new Keyboard;

	// Create instance of state machine
	myStateMachine = new StateMachine;

	// Start timer for each diagram which needs one in the first state!
	// In my case these are diagram 0 and 2
	myStateMachine->diaTimerTable[0]->startTimer(tab[0][0]->eventTime);
	myStateMachine->diaTimerTable[1]->startTimer(tab[1][0]->eventTime);
	myStateMachine->diaTimerTable[2]->startTimer(tab[2][0]->eventTime);
	
	//********************
//	myTCPServer = new TCPServer;
//	myTCPServer->init();
//	
//	myTelnetServer = new TelnetServer;
//	myTelnetServer->init();
	
	//????? da dies eine C-Datei ist, kann vermutlich kein Objekt so erzeugt werden
	myTCPClient = new TCPClient;
	myTCPClient->init(); 
	
	// Initial actions can be done here, if needed!
	n = 0;
	m = 0;

	return;
}

// Actions for State-Machine in Local Operation Mode (LOM)
void myAction00(){
	writeToDisplay(1, 1, "IDLE_LOM -> D_changeMode_LOM_to_COM -> IDLE_COM                                     ");
	return;
}
void myAction01(){
	writeToDisplay(1, 1, "IDLE_LOM -> 1_keyDriveLeft  -> RunLeft                                              ");
	return;
}
void myAction02(){ 
	writeToDisplay(1, 1, "IDLE_LOM -> 3_keyDriveRight  -> RunRight                                             ");
	return;
}
void myAction03(){
	writeToDisplay(1, 1, "RunLeft -> F_finishedProfile  -> IDLE_LOM                                            ");
	return; 
}
void myAction04(){
	writeToDisplay(1, 1, "RunLeft -> 0_stop  -> IDLE_LOM                                                        ");
	return;
}
void myAction05(){
	writeToDisplay(1, 1, "RunRight -> F_finishedProfile  -> IDLE_LOM                                            ");
	return;
}
void myAction06(){
	writeToDisplay(1, 1, "RunRight -> 0_stop  -> IDLE_LOM                                                       ");
	return;
}
void myAction07(){
	writeToDisplay(1, 1, "IDLE_LOM -> 6_speedUp  -> IDLE_LOM                                                     ");
	return;
}
void myAction08(){
	writeToDisplay(1, 1, "IDLE_LOM -> 4_speedDown  -> IDLE_LOM                                                   ");
	return;
}


// Actions for State-Machine in Chain Operation Mode (COM)
void myAction10(){
	writeToDisplay(1, 1, "IDLE_COM -> E_changeMode_COM_to_LOM  -> IDLE_LOM                                        ");
	return;
}
void myAction11(){
	writeToDisplay(1, 1, "IDLE_COM -> A_requestReceived  -> PayloadPassingFromLeft                                ");
	return;
}
void myAction12(){
	writeToDisplay(1, 1, "PayloadPassingFromLeft -> 7_releaseSentToLeft  -> MoveProfile                           ");
	return;
}
void myAction13(){
	writeToDisplay(1, 1, "MoveProfile -> A_requestReceived  -> MoveProfile                                        ");
	return;
}
void myAction14(){
	writeToDisplay(1, 1, "MoveProfile -> 9_sendToLeftWait  -> MoveProfile                                          ");
	return;
}
void myAction15(){
	writeToDisplay(1, 1, "MoveProfile -> B_readyReceived  -> PayloadPassingToRight                                  ");
	return;
}
void myAction16(){
	writeToDisplay(1, 1, "MoveProfile -> 8_waitReceived  -> Stop                                                    ");
	return;
}
void myAction17(){
	writeToDisplay(1, 1, "Stop -> B_readyReceived  -> PayloadPassingToRight                                         ");
	return;
}
void myAction18(){
	writeToDisplay(1, 1, "PayloadPassingToRight -> C_releasedReceivedFromRight  -> IDLE_COM                           ");
	return;
}

//hier kommen die Transitionen rein, da hier die Tastatur kontinuierlich abgefragt wird
// --> anfangs mit "cases" und senden an tab[][].... mittels Triggerevents
void myAction20(){

		switch (myKeyboard->getPressedKey())
		{
		//LOM
	case '0':
		myStateMachine->sendEvent("0_stop");
		break;	
	case '1':
		myStateMachine->sendEvent("1_keyDriveLeft");
		break;		
	case '3':
		myStateMachine->sendEvent("3_keyDriveRight");
		break;							
	case '4': 
		myStateMachine->sendEvent("4_speedDown");
		break;		
	case '6':
		myStateMachine->sendEvent("6_speedUp");
		break;		
	case 'F':
		myStateMachine->sendEvent("F_finishedProfile");
		break;			
	case 'E':
		myStateMachine->sendEvent("E_changeMode_COM_to_LOM");
		break;	
		
//******************************************************************************			
	
		//COM
	case 'A':
		myStateMachine->sendEvent("A_requestReceived");
		break;		
	case '7':
		myStateMachine->sendEvent("7_releaseSentToLeft");
		break;		
	case '8':
		myStateMachine->sendEvent("8_waitReceived");
		break;		
	case '9':
		myStateMachine->sendEvent("9_sendToLeftWait");
		break;		
	case 'B':
		myStateMachine->sendEvent("B_readyReceived");
		break;		
	case 'C':
		myStateMachine->sendEvent("C_releasedReceivedFromRight");
		break;		
	case 'D':
		myStateMachine->sendEvent("D_changeMode_LOM_to_COM");
		break;						
	default:		
		break;
		}
		
	return;
}

bool myConditionTrue(){
	return TRUE;
}

bool myCondition00(){
	return TRUE;
}

bool myCondition01(){
	return TRUE;
}

bool myCondition11(){
	if (m < 4) return TRUE;
	else return FALSE;
}

bool myCondition12(){
	if (m >= 4) return TRUE;
	else return FALSE;
}

