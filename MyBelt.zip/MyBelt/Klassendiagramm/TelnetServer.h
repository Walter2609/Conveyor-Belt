

#ifndef TELNETSERVER_H_
#define TELNETSERVER_H_

#include "ICommand.h"

class TelnetServer{
	
private:
	ICommand mCommand;
		
public:
	TelnetServer();
	void receiveCommand();
	void sendCommand();
	void init();
	//void TelnetServerWorkTask(int sFd, char* address, u_short port);
	//STATUS rTCPS(void);
	
};

#endif // TELNETSERVER_H_
