

#ifndef TCPSERVER_H_
#define TCPSERVER_H_

#include "ICommand.h"

class TCPServer{
	
private:
	ICommand mCommand;
		
public:
	TCPServer();
	void receiveCommand();
	void sendCommand();
	void init();
	//void tcpServerWorkTask(int sFd, char* address, u_short port);
	//STATUS rTCPS(void);
	
};

#endif // TCPSERVER_H_
