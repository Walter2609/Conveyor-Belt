#include "ICommand.h"

ICommand :: ICommand(){
	return;		
}

void ICommand :: parseCommand(){
	return;		
}

