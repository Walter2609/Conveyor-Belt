
#include <taskLib.h>
#include <stdio.h>
#include <intLib.h>
#include <sysLib.h>
#include <stdLib.h>
#include "ifLib.h"
#include "MyBelt.h"
#include "StateMachine.h"

extern "C" {
	#include "hwFunc.h"
}

MyBelt * myBelt;
StateMachine * myStateMachine;


void setLocalIp();


int main (void) {
	
    initHardware(0);

    writeToDisplay(1, 1, "Hallo1");
	// Set tick to 5 ms. This is the time resolution!
	sysClkRateSet(200);
	
	// Set local IP address according to MAC table
	setLocalIp();

	// Create instance of top class
	myBelt = new MyBelt;

	// Start the state machine. This method blocks, so no while(1) is needed.
	myStateMachine->runToCompletion();
	
}
