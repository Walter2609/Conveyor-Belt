

#ifndef TCPCLIENT_H_
#define TCPCLIENT_H_

#include "ICommand.h"

class TCPClient{
	
private:
	ICommand mCommand;
		
public:
	TCPClient();
	void receiveCommand();
	void sendCommand();
	void init();
	void initSlaves();
	void initPlaying();
	//void tcpClientWorkTask(int sFd, char* address, u_short port);
	//STATUS rTCPS(void);
	
};

#endif // TCPCLIENT_H_
