#include "CTelnet.h"

#include <stdio.h>
#include <stdlib.h>
#include <sysLib.h>
#include <ioLib.h>


void parseTelnet() {
	return;
}

