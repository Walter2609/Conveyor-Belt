#include "TCPServer.h"
#include <vxWorks.h>
#include <sockLib.h>
#include <stdlib.h>
#include <stdioLib.h>
#include <strLib.h>
#include <stdio.h>
#include <ioLib.h>
#include <fioLib.h>
#include <intLib.h>
#include <inetLib.h>
#include <taskLib.h>
#include <sysLib.h>
#include <time.h>
#include <string.h>
#include "hwFunc.h"
#include "disp.h"
#include "FHV.h"
#include "hw.h"
#include "MyBelt.h"
#include "stateMachine.h"


#define SERVER_PORT_NUM 5555 /* server's port number for bind() */
#define SERVER_WORK_PRIORITY 100 /* priority of server's work task */
#define SERVER_STACK_SIZE 10000 /* stack size of server's work task */
#define SERVER_MAX_CONNECTIONS 4 /* max clients connected at a time */
#define REQUEST_MSG_SIZE 1024 /* max size of request message */
#define REPLY_MSG_SIZE 500 /* max size of reply message */
/* structure for requests from clients to server */

StateMachine * myStateMachine;
VOID tcpServerWorkTask (int sFd, char * address, u_short port);

struct request
{
	int reply; /* TRUE = request reply from server */
	int msgLen; /* length of message text */
	char message[REQUEST_MSG_SIZE]; /* message buffer */
};



TCPServer :: TCPServer(){
	printf("TCPServer Konstruktor!\n\r");	
		return;
	}	


void TCPServer :: receiveCommand(){
		return;
	}
	

void TCPServer :: sendCommand(){
		return;
	}


STATUS rTCPS(void)
{
	struct sockaddr_in serverAddr; // server's socket address 
	struct sockaddr_in clientAddr; // client's socket address 
	int sockAddrSize; // size of socket address structure 
	int sFd; // socket file descriptor 
	int newFd; // socket descriptor from accept 
	int ix = 0; // counter for work task names 
	char workName[16]; // name of work task 
	
	// set up the local address
	
	socklen_t len = sizeof(clientAddr);
	sockAddrSize = sizeof (struct sockaddr_in);
	bzero ((char *) &serverAddr, sockAddrSize);
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_len = (u_char) sockAddrSize;
	serverAddr.sin_port = htons (SERVER_PORT_NUM);
	serverAddr.sin_addr.s_addr = htonl (INADDR_ANY);
	
	// create a TCP-based socket 
	
	if ((sFd = socket (AF_INET, SOCK_STREAM, 0)) == ERROR)
	{
		perror ("socket");
		return (ERROR);
	}
	
	// bind socket to local address 
	if (bind (sFd, (struct sockaddr *) &serverAddr, sockAddrSize) == ERROR)
	{
		perror ("bind");
		close (sFd);
		return (ERROR);
	}
	
	// create queue for client connection requests 
	if (listen (sFd, SERVER_MAX_CONNECTIONS) == ERROR)
	{
		perror ("listen");
		close (sFd);
		return (ERROR);
	}
	
	// accept new connect requests and spawn tasks to process them 
	FOREVER
	{
		int len = sizeof(clientAddr);
		if ((newFd = accept (sFd, (struct sockaddr *) &clientAddr, &len)) == ERROR)
		{
			perror ("accept");
			close (sFd);
			return (ERROR);
		}
		
		sprintf (workName, "tTcpWork%d", ix++);
		if (taskSpawn(workName, SERVER_WORK_PRIORITY, 0, SERVER_STACK_SIZE, (FUNCPTR) tcpServerWorkTask, newFd,
			(int) inet_ntoa (clientAddr.sin_addr), ntohs (clientAddr.sin_port), 0, 0, 0, 0, 0, 0, 0) == ERROR)
		{
			// if taskSpawn fails, close fd and return to top of loop 
			perror ("taskSpawn");
			close (newFd);
		}
	}
}

// structure for requests from clients to server 
// The TCP server shall accept the command �Request\r\n� either from its left neighbor or from the master.
VOID tcpServerWorkTask( int sFd, //server's socket fd
						char * address, // client's socket address 
						u_short port /* client's socket port*/ ) 
{
	char outputstring1[50];
	//write(sFd, "Hallo....ich bin Emines und Walters TcpServerWorkTask\n", 50);
	
	//request/message from client
	struct request clientRequest;  
	int nRead; /* number of bytes read */
	static char replyMsg[] = "Server received your message";
	static char welcomeMsg[] = "Hallo....ich bin Emines und Walters TcpServerWorkTask\n";
	/* read client request, display message */
	
	char tcpBuffer[99];
		/* read client request, display message */
		write(sFd,welcomeMsg,sizeof(welcomeMsg));
		//OLD:while ((nRead = fioRead (sFd, (char *) &clientRequest,
		//                         sizeof (clientRequest))) > 0)
		//new
		while ((nRead = fioRdString (sFd, (char *) &clientRequest.message,
			                         sizeof (clientRequest.message))) > 0)
		{
			switch (clientRequest.message[0])
			{
					//LOM
				case '0':
					myStateMachine->sendEvent("0_stop");
					break;	
				case '1':
					myStateMachine->sendEvent("1_keyDriveLeft");
					break;		
				case '3':
					myStateMachine->sendEvent("3_keyDriveRight");
					break;								
				case '4': 
					myStateMachine->sendEvent("4_speedDown");
					break;		
				case '6':
					myStateMachine->sendEvent("6_speedUp");
					break;			
				case 'F':
					myStateMachine->sendEvent("F_finishedProfile");
					break;			
				case 'E':
					myStateMachine->sendEvent("E_changeMode_COM_to_LOM");
					break;	
					
					//COM
				case 'A':
					myStateMachine->sendEvent("A_requestReceived");
					break;		
				case '7':
					myStateMachine->sendEvent("7_releaseSentToLeft");
					break;		
				case '8':
					myStateMachine->sendEvent("8_waitReceived");
					break;			
				case '9':
					myStateMachine->sendEvent("9_sendToLeftWait");
					break;		
				case 'B':
					myStateMachine->sendEvent("B_readyReceived");
					break;		
				case 'C':
					myStateMachine->sendEvent("C_releasedReceivedFromRight");
					break;		
				case 'D':
					myStateMachine->sendEvent("D_changeMode_LOM_to_COM");
					break;								
				default:
					
					break;
		}
		write(sFd, outputstring1, sizeof(outputstring1));
	}	
	if (nRead == ERROR) /* error from read() */
		perror ("read");
	close (sFd); /* close server socket connection */
	//...
	//...
	//...
}





void TCPServer :: init() {
	taskSpawn("myTCPServer", 101, 0, 0x1000,  (FUNCPTR) rTCPS, 0,0,0,0,0,0,0,0,0,0);
	return;
}


