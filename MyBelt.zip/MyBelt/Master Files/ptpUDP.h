
STATUS receiveUDP (struct request * myRequestP);

STATUS sendUDP (struct request * myRequestP);
