/*
 * File: Stromregler_data.c
 *
 * Code generated for Simulink model 'Stromregler'.
 *
 * Model version                  : 1.16
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Fri Nov 27 11:07:27 2015
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Stromregler.h"
#include "Stromregler_private.h"

/* Block parameters (auto storage) */
P_Stromregler_T Stromregler_P = {
  0.03,                                /* Variable: KRI1
                                        * Referenced by:
                                        *   '<S1>/Gain'
                                        *   '<S1>/Gain1'
                                        */
  0.015,                               /* Variable: KRI2
                                        * Referenced by:
                                        *   '<S1>/Gain2'
                                        *   '<S1>/Gain3'
                                        */
  3.5,                                 /* Variable: TN1
                                        * Referenced by: '<S1>/Gain1'
                                        */
  0.25,                                /* Variable: TN2
                                        * Referenced by: '<S1>/Gain3'
                                        */
  0.05,                                /* Variable: TRI1
                                        * Referenced by: '<S1>/Gain1'
                                        */
  0.005,                               /* Variable: TRI2
                                        * Referenced by: '<S1>/Gain3'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S1>/Unit Delay2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S1>/Unit Delay'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S1>/Unit Delay1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S1>/Unit Delay3'
                                        */
  9.0,                                 /* Expression: 9
                                        * Referenced by: '<S1>/Anti Wind up2'
                                        */
  -9.0                                 /* Expression: -9
                                        * Referenced by: '<S1>/Anti Wind up2'
                                        */
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
